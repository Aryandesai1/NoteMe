package com.example.notemeedition;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.Objects;

public class Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Activity 2");
   getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}